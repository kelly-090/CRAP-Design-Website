        <footer>
        <div id="bottom_text">
            <a href="https://solace.ist.rit.edu/~iste240t29/contrast.php">Learn</a>
            <a href="https://solace.ist.rit.edu/~iste240t29/quiz.php">Test Your Knowledge</a>
            <a href>References</a>
        </div>
        
        
            <p class="copyright">&copy; 2025 - CRAPMasters</p>

        </footer>
    </body>
</html>